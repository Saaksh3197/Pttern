/**
 * 
 */
/**
 * @author shree
 *
 */
module com.pattern {
}
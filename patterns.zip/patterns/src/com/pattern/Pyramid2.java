package com.pattern;

public class Pyramid2 {

	public static void main(String[] args) {
	  byte m=5;
	  byte n=5;
	  for(int i=1; i<=m; i++) {
		  for(int j=i; j<=n; j++) {
			  System.out.print(" * ");
		  }System.out.println();
	  }

	}

}

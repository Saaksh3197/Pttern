package com.pattern;

public class Pyramid3 {

	public static void main(String[] args) {
		int m=5;
		for(int i=m; i>=1; i--) {
			for(int j=i; j<=m; j++) {
				System.out.print(" * ");
			}System.out.println();
		}
	}

}

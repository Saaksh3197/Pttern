package com.pattern;

public class Pyramid1 {

	public static void main(String[] args) {
		byte m=4;
		for(int i=1; i<=m; i++) {
			for(int j=i; j<=m; j++) {
				System.out.print(" * ");
			}System.out.println();
		}
	}

}
